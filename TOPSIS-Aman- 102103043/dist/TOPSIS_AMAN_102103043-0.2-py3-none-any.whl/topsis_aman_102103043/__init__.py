# topsis_aman_102103043/__init__.py

from .aman import topsis
